import { createRouter, createWebHistory } from 'vue-router'
import HomeView from './components/home.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView,
    },
    {
      path: '/barenpark_randomiser',
      name: 'Barenpark Randomiser',
      // route level code-splitting
      // this generates a separate chunk (About.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import('./components/barenpark_randomiser.vue'),
    },
  ],
})

export default router